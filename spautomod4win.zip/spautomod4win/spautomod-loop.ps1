Start-Process -FilePath "spautomod.exe" -ArgumentList "--loop" -Wait -WindowStyle Maximized
